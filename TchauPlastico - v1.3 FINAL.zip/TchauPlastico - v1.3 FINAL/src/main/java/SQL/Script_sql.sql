CREATE DATABASE server_a3;
USE server_a3;

Create table tb_usuario(
codusu int primary key auto_increment, nomeusu varchar(200) not null,
emailusu varchar(200), senhausu varchar(200) default "12345", admusu bool default false 
); 

insert into tb_usuario
(nomeusu, emailusu) values
("adm", "adm@adm");

DELETE FROM tb_usuario WHERE codusu=0; -- <---- Deletar uma linha da tabela!

select * from tb_usuario;

Create table tb_registro(
codregi int primary key auto_increment, oxi varchar(200),
ph varchar(200), sali varchar(200), od varchar(200), co2 varchar(200),
lux varchar(200), po varchar(200), contmicro varchar(200), ciclo varchar(200),
bm varchar(200)
);

select * from tb_registro;