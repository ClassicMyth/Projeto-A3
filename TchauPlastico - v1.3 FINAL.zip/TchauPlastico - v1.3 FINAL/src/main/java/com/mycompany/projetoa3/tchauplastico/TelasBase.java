/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.mycompany.projetoa3.tchauplastico;

import com.mycompany.DAO.ConnectionFactory;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author Aluno
 */
public class TelasBase extends javax.swing.JFrame {

    /**
     * Creates new form TelasBase
     */
    public TelasBase() {
        initComponents();
    }
   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jFrame1 = new javax.swing.JFrame();
        jFrame2 = new javax.swing.JFrame();
        contaNova = new javax.swing.JButton();
        entrar = new javax.swing.JButton();
        esqueciSenha = new javax.swing.JButton();
        DigitarEmail = new javax.swing.JTextField();
        DigitarSenha = new javax.swing.JPasswordField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        fundo = new javax.swing.JLabel();

        jTextArea1.setColumns(20);
        jTextArea1.setRows(5);
        jScrollPane1.setViewportView(jTextArea1);

        javax.swing.GroupLayout jFrame1Layout = new javax.swing.GroupLayout(jFrame1.getContentPane());
        jFrame1.getContentPane().setLayout(jFrame1Layout);
        jFrame1Layout.setHorizontalGroup(
            jFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        jFrame1Layout.setVerticalGroup(
            jFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jFrame2Layout = new javax.swing.GroupLayout(jFrame2.getContentPane());
        jFrame2.getContentPane().setLayout(jFrame2Layout);
        jFrame2Layout.setHorizontalGroup(
            jFrame2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        jFrame2Layout.setVerticalGroup(
            jFrame2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setAutoRequestFocus(false);
        setBackground(new java.awt.Color(51, 0, 102));
        setMinimumSize(new java.awt.Dimension(1920, 1080));
        getContentPane().setLayout(null);

        contaNova.setFont(new java.awt.Font("Segoe UI", 0, 30)); // NOI18N
        contaNova.setLabel("Criar Conta");
        contaNova.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                contaNovaActionPerformed(evt);
            }
        });
        getContentPane().add(contaNova);
        contaNova.setBounds(1310, 760, 184, 71);

        entrar.setFont(new java.awt.Font("Segoe UI", 0, 30)); // NOI18N
        entrar.setLabel("Entrar");
        entrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                entrarActionPerformed(evt);
            }
        });
        getContentPane().add(entrar);
        entrar.setBounds(1310, 680, 184, 71);

        esqueciSenha.setFont(new java.awt.Font("Arial", 2, 25)); // NOI18N
        esqueciSenha.setText("Esqueci a senha");
        esqueciSenha.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                esqueciSenhaActionPerformed(evt);
            }
        });
        getContentPane().add(esqueciSenha);
        esqueciSenha.setBounds(1460, 610, 221, 41);

        DigitarEmail.setFont(new java.awt.Font("Arial", 2, 40)); // NOI18N
        DigitarEmail.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DigitarEmailActionPerformed(evt);
            }
        });
        getContentPane().add(DigitarEmail);
        DigitarEmail.setBounds(1100, 340, 570, 71);

        DigitarSenha.setFont(new java.awt.Font("Arial", 2, 40)); // NOI18N
        DigitarSenha.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DigitarSenhaActionPerformed(evt);
            }
        });
        getContentPane().add(DigitarSenha);
        DigitarSenha.setBounds(1100, 510, 570, 71);

        jLabel1.setFont(new java.awt.Font("Segoe UI", 0, 50)); // NOI18N
        jLabel1.setText("Acesso");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(1100, 270, 160, 67);

        jLabel2.setFont(new java.awt.Font("Segoe UI", 0, 50)); // NOI18N
        jLabel2.setText("Senha");
        getContentPane().add(jLabel2);
        jLabel2.setBounds(1100, 440, 140, 67);

        jLabel3.setBackground(new java.awt.Color(255, 255, 255));
        jLabel3.setFont(new java.awt.Font("Segoe UI", 0, 150)); // NOI18N
        jLabel3.setText("Bem-vindo!");
        getContentPane().add(jLabel3);
        jLabel3.setBounds(1010, 110, 770, 139);

        fundo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/directory/Save_the_ocean__20241009_222758_0000.png"))); // NOI18N
        getContentPane().add(fundo);
        fundo.setBounds(0, 0, 1920, 1080);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void DigitarEmailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DigitarEmailActionPerformed
        
    }//GEN-LAST:event_DigitarEmailActionPerformed
    
     public String getEmail() {
        return DigitarEmail.getText();
    }

    // Método para acessar a senha digitada no campo DigitarSenha
   
    private void entrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_entrarActionPerformed
    
    ConnectionFactory cf = new ConnectionFactory();
    Connection conn = cf.obtemConexao();

    String sql = "SELECT * FROM tb_usuario WHERE emailusu = ? AND senhausu = ?";

    try {
        PreparedStatement ps = conn.prepareStatement(sql);

        ps.setString(1, DigitarEmail.getText());
        ps.setString(2, new String(DigitarSenha.getPassword()));

        ResultSet rs = ps.executeQuery();

        if (rs.next()) {
            String nivelAcesso = rs.getString("codusu");

            if ("1".equalsIgnoreCase(nivelAcesso)) {
                // Usuário administrador
                JOptionPane.showMessageDialog(null, "Bem-vindo, administrador!");
                new HomeAdmin().setVisible(true); // Abrir tela de administração
                this.dispose(); // Fecha a tela de login
            } else {
                // Usuário comum
                JOptionPane.showMessageDialog(null, "Bem-vindo!");
                new HomePage().setVisible(true); // Abrir HomePage
                this.dispose(); // Fecha a tela de login
            }
        } else {
            // Login inválido
            JOptionPane.showMessageDialog(null, "Email ou senha incorretos!");
            DigitarEmail.setText("");
            DigitarSenha.setText("");
        }

        rs.close();
        ps.close();
        conn.close();

    } catch (SQLException ex) {
        Logger.getLogger(TelasBase.class.getName()).log(Level.SEVERE, null, ex);
        JOptionPane.showMessageDialog(null, "Erro ao conectar ao banco de dados.");
    }
    }//GEN-LAST:event_entrarActionPerformed

    private void contaNovaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_contaNovaActionPerformed
        
        TelaCadastro exibir = new TelaCadastro();
        exibir.setVisible(true);
                
        setVisible(false);
    }//GEN-LAST:event_contaNovaActionPerformed

    private void esqueciSenhaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_esqueciSenhaActionPerformed
        
        TelaEsqueciSenha exibir = new TelaEsqueciSenha();
        exibir.setVisible(true);
        
    }//GEN-LAST:event_esqueciSenhaActionPerformed

    private void DigitarSenhaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DigitarSenhaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_DigitarSenhaActionPerformed
   
    public String getSenha() {
        return new String(DigitarSenha.getPassword());
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TelasBase.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TelasBase.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TelasBase.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TelasBase.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TelasBase().setVisible(true);
            }
        });
    }

    private void signInBtn() {
        String name, password;
        String SUrl, SUser, Spass;

        try {
            Class.forName("com.mysql.cj.jdbc.driver");
            SUrl = "jdbc:MySQL://localhost:3306/";
            
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField DigitarEmail;
    private javax.swing.JPasswordField DigitarSenha;
    private javax.swing.JButton contaNova;
    private javax.swing.JButton entrar;
    private javax.swing.JButton esqueciSenha;
    private javax.swing.JLabel fundo;
    private javax.swing.JFrame jFrame1;
    private javax.swing.JFrame jFrame2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextArea jTextArea1;
    // End of variables declaration//GEN-END:variables
}
