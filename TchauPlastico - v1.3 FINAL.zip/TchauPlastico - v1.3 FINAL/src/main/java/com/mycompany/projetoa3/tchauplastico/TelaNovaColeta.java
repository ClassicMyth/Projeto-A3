/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.mycompany.projetoa3.tchauplastico;

import com.mycompany.DAO.ConnectionFactory;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author vynyt
 */
public class TelaNovaColeta extends javax.swing.JFrame {

    TelasBase telasBase = new TelasBase();
   
    public TelaNovaColeta() {
        initComponents();
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Oxi = new javax.swing.JTextField();
        PH = new javax.swing.JTextField();
        Car = new javax.swing.JTextField();
        Sal = new javax.swing.JTextField();
        BiomassaGerada = new javax.swing.JTextField();
        Graus1 = new javax.swing.JTextField();
        Luz = new javax.swing.JTextField();
        Pressao = new javax.swing.JTextField();
        CicloDaVida = new javax.swing.JTextField();
        Contam = new javax.swing.JTextField();
        javax.swing.JButton Verificar = new javax.swing.JButton();
        Voltar = new javax.swing.JButton();
        Limpar = new javax.swing.JButton();
        Home = new javax.swing.JLabel();
        NovaColeta = new javax.swing.JLabel();
        LabelHP = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(1920, 1080));
        getContentPane().setLayout(null);

        Oxi.setFont(new java.awt.Font("Arial", 0, 40)); // NOI18N
        Oxi.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        Oxi.setText("Inserir Oxigênio");
        Oxi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                OxiActionPerformed(evt);
            }
        });
        getContentPane().add(Oxi);
        Oxi.setBounds(840, 600, 420, 90);

        PH.setFont(new java.awt.Font("Arial", 0, 40)); // NOI18N
        PH.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        PH.setText("Inserir pH");
        PH.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PHActionPerformed(evt);
            }
        });
        getContentPane().add(PH);
        PH.setBounds(830, 340, 430, 90);

        Car.setFont(new java.awt.Font("Arial", 0, 40)); // NOI18N
        Car.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        Car.setText("Inserir Gás Carbônico");
        Car.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CarActionPerformed(evt);
            }
        });
        getContentPane().add(Car);
        Car.setBounds(840, 730, 420, 90);

        Sal.setFont(new java.awt.Font("Arial", 0, 40)); // NOI18N
        Sal.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        Sal.setText("Inserir Salinidade");
        Sal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SalActionPerformed(evt);
            }
        });
        getContentPane().add(Sal);
        Sal.setBounds(840, 470, 420, 90);

        BiomassaGerada.setFont(new java.awt.Font("Arial", 0, 40)); // NOI18N
        BiomassaGerada.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        BiomassaGerada.setText("Inserir Biomassa ");
        BiomassaGerada.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BiomassaGeradaActionPerformed(evt);
            }
        });
        getContentPane().add(BiomassaGerada);
        BiomassaGerada.setBounds(1410, 730, 380, 90);

        Graus1.setFont(new java.awt.Font("Arial", 0, 40)); // NOI18N
        Graus1.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        Graus1.setText("Inserir Temperatura");
        Graus1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Graus1ActionPerformed(evt);
            }
        });
        getContentPane().add(Graus1);
        Graus1.setBounds(830, 210, 430, 90);

        Luz.setFont(new java.awt.Font("Arial", 0, 40)); // NOI18N
        Luz.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        Luz.setText("Inserir Luminosidade");
        Luz.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LuzActionPerformed(evt);
            }
        });
        getContentPane().add(Luz);
        Luz.setBounds(1410, 210, 380, 90);

        Pressao.setFont(new java.awt.Font("Arial", 0, 40)); // NOI18N
        Pressao.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        Pressao.setText("Inserir Pres. Osm.");
        Pressao.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PressaoActionPerformed(evt);
            }
        });
        getContentPane().add(Pressao);
        Pressao.setBounds(1410, 340, 380, 90);

        CicloDaVida.setFont(new java.awt.Font("Arial", 0, 40)); // NOI18N
        CicloDaVida.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        CicloDaVida.setText("Inserir Ciclo da Vida");
        CicloDaVida.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CicloDaVidaActionPerformed(evt);
            }
        });
        getContentPane().add(CicloDaVida);
        CicloDaVida.setBounds(1410, 600, 380, 90);

        Contam.setFont(new java.awt.Font("Arial", 0, 40)); // NOI18N
        Contam.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        Contam.setText("Inserir Cont. Micro.");
        Contam.setToolTipText("");
        Contam.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ContamActionPerformed(evt);
            }
        });
        getContentPane().add(Contam);
        Contam.setBounds(1410, 470, 380, 90);

        Verificar.setFont(new java.awt.Font("Arial", 0, 27)); // NOI18N
        Verificar.setText("Verificar");
        Verificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                VerificarActionPerformed(evt);
            }
        });
        getContentPane().add(Verificar);
        Verificar.setBounds(1210, 890, 170, 70);

        Voltar.setFont(new java.awt.Font("Arial", 3, 15)); // NOI18N
        Voltar.setContentAreaFilled(false);
        Voltar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                VoltarActionPerformed(evt);
            }
        });
        getContentPane().add(Voltar);
        Voltar.setBounds(30, 830, 170, 190);

        Limpar.setFont(new java.awt.Font("Arial", 0, 20)); // NOI18N
        Limpar.setText("Limpar");
        Limpar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LimparActionPerformed(evt);
            }
        });
        getContentPane().add(Limpar);
        Limpar.setBounds(700, 890, 130, 70);

        Home.setFont(new java.awt.Font("Arial", 0, 20)); // NOI18N
        Home.setText("← Home");
        getContentPane().add(Home);
        Home.setBounds(210, 920, 110, 40);

        NovaColeta.setIcon(new javax.swing.ImageIcon(getClass().getResource("/directory/NovaColeta.png"))); // NOI18N
        NovaColeta.setMaximumSize(new java.awt.Dimension(19200, 10800));
        getContentPane().add(NovaColeta);
        NovaColeta.setBounds(0, 0, 1920, 1030);

        LabelHP.setFont(new java.awt.Font("Arial", 3, 25)); // NOI18N
        LabelHP.setText("← Home");
        getContentPane().add(LabelHP);
        LabelHP.setBounds(240, 930, 110, 80);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void OxiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_OxiActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_OxiActionPerformed

    private void PHActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PHActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_PHActionPerformed

    private void SalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SalActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_SalActionPerformed

    private void CarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_CarActionPerformed

    private void LuzActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LuzActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_LuzActionPerformed

    private void PressaoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PressaoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_PressaoActionPerformed

    private void ContamActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ContamActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ContamActionPerformed

    private void CicloDaVidaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CicloDaVidaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_CicloDaVidaActionPerformed

    private void BiomassaGeradaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BiomassaGeradaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_BiomassaGeradaActionPerformed

    private void Graus1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Graus1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Graus1ActionPerformed

        // true = admin, false = usuário comum

    
    private void VoltarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_VoltarActionPerformed
        
        HomePage exibir = new HomePage();
        exibir.setVisible(true);
        
        setVisible(false);
        
        this.dispose();
    }//GEN-LAST:event_VoltarActionPerformed

    private void VerificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_VerificarActionPerformed
        // TODO add your handling code here:
        
        if (Graus1.getText().isEmpty() || PH.getText().isEmpty() || Sal.getText().isEmpty() || Oxi.getText().isEmpty() || 
            Car.getText().isEmpty() || Luz.getText().isEmpty() || Pressao.getText().isEmpty() || Contam.getText().isEmpty() || 
            CicloDaVida.getText().isEmpty() || BiomassaGerada.getText().isEmpty()) {
            
            JOptionPane.showMessageDialog(null, "Por favor, insira dados em todos os campos!");
            return;
        } 
        
        double temperatura = Double.parseDouble(Graus1.getText());
        double ph = Double.parseDouble(PH.getText());
        double salinidade = Double.parseDouble(Sal.getText());
        double od = Double.parseDouble(Oxi.getText());
        double gasC = Double.parseDouble(Car.getText());
        double lum = Double.parseDouble(Luz.getText());
        double po = Double.parseDouble(Pressao.getText());
        double cont = Double.parseDouble(Contam.getText());
        double ciclo = Double.parseDouble(CicloDaVida.getText());
        double bm = Double.parseDouble(BiomassaGerada.getText());
        
       ConnectionFactory cf = new ConnectionFactory();
       Connection conn = cf.obtemConexao();
       String sql = "insert into tb_registro(graus, ph, sali, od, co2, lux, po, contmicro, ciclo, bm) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
       
       try {
            PreparedStatement ps = conn.prepareStatement(sql);
            
            ps.setDouble(1, temperatura);
            ps.setDouble(2, ph);
            ps.setDouble(3, salinidade);
            ps.setDouble(4, od);
            ps.setDouble(5, gasC);
            ps.setDouble(6, lum);
            ps.setDouble(7, po);
            ps.setDouble(8, cont);
            ps.setDouble(9, ciclo);
            ps.setDouble(10, bm);
            
            
            ps.execute();
            
            ps.close();
            conn.close();

       } catch (SQLException ex) {
            Logger.getLogger(TelaCadastro.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Erro!!!");
        }
       
        Integer foraIdeal = 0;
        
        
        if(temperatura >= 18 && temperatura <= 25){
            Graus1.setText(temperatura + " OK!");
        }else{
            Graus1.setText(temperatura + " Não Ideal!");
            foraIdeal++;
        }
        if(ph >= 7.5 && ph <= 8.5){
            PH.setText(ph + " OK!");
            
        }else{
            PH.setText(ph + " Não Ideal!");
            foraIdeal++;
        }
        if(salinidade >= 25 && salinidade <= 35){
            Sal.setText(salinidade + " OK!");
            
        }else{
            Sal.setText(salinidade + " Não Ideal!");
            foraIdeal++;
        }
        if(od >= 4 && od <= 7){
            Oxi.setText(od + " OK!");
            
        }else{
            Oxi.setText(od + " Não Ideal!");
            foraIdeal++;
        }
        if(gasC >= 10 && gasC <= 20){
            Car.setText(gasC + " OK!");
            
        }else{
            Car.setText(gasC + " Não Ideal!");
            foraIdeal++;
        }
        if(lum >= 100 && lum <= 300){
            Luz.setText(lum + " OK!");
            
        }else{
            Luz.setText(lum + " Não Ideal!");
            foraIdeal++;
        }
        if(po >= 0.5 && po <= 1.5){
            Pressao.setText(po + " OK!");
            
        }else{
            Pressao.setText(po + " Não Ideal!");
            foraIdeal++;
        }
        if(cont == 1){
            Contam.setText(cont + " Sim");
        }else{
            Contam.setText(cont + " Não");
        }
        if(ciclo >= 9 && ciclo <= 12){
            CicloDaVida.setText(ciclo + " OK!");
            
        }else{
             CicloDaVida.setText(ciclo + " Não Ideal!");
             foraIdeal++;
        }
          if(bm >= 8 && bm <= 10){
            BiomassaGerada.setText(bm + " OK!");
            
        }else{
              BiomassaGerada.setText(bm + " Não Ideal!");
              foraIdeal++;
          }
        if(foraIdeal >= 4){
            JOptionPane.showMessageDialog(null, "Existem " + foraIdeal + " parâmetros fora do ideal. Por favor, reinicie o meio de cultivo ou coloque os parâmetros corretamente!.");
        }else{
            JOptionPane.showMessageDialog(null, "Os paramêtros estão ideais para a coleta!");
        }
    }//GEN-LAST:event_VerificarActionPerformed

    private void LimparActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LimparActionPerformed
        // TODO add your handling code here:
        Graus1.setText("");
        PH.setText("");
        Sal.setText("");
        Oxi.setText("");
        Car.setText("");
        Luz.setText("");
        Pressao.setText("");
        Contam.setText("");
        CicloDaVida.setText("");
        BiomassaGerada.setText("");
    }//GEN-LAST:event_LimparActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TelaNovaColeta.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TelaNovaColeta.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TelaNovaColeta.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TelaNovaColeta.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TelaNovaColeta().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField BiomassaGerada;
    private javax.swing.JTextField Car;
    private javax.swing.JTextField CicloDaVida;
    private javax.swing.JTextField Contam;
    private javax.swing.JTextField Graus1;
    private javax.swing.JLabel Home;
    private javax.swing.JLabel LabelHP;
    private javax.swing.JButton Limpar;
    private javax.swing.JTextField Luz;
    private javax.swing.JLabel NovaColeta;
    private javax.swing.JTextField Oxi;
    private javax.swing.JTextField PH;
    private javax.swing.JTextField Pressao;
    private javax.swing.JTextField Sal;
    private javax.swing.JButton Voltar;
    // End of variables declaration//GEN-END:variables
}
