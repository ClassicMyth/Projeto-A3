package com.mycompany.DAO;

import java.sql.Connection;
import java.sql.DriverManager;

public class ConnectionFactory {
    private String usuario = "root";
    private String senha = "Gabideconto010203";
    private String host = "localhost";
    private String porta = "3306";
    private String bd = "server_a3";
    public Connection obtemConexao(){
            try{
                Connection c = DriverManager.getConnection(
                "jdbc:mysql://" + host + ":" + porta + "/" + bd + "?serverTimezone=UTC", usuario, senha);
                System.out.println("...Conexao <OK>...");
                return c;
            }
            catch (Exception e) {
                e.printStackTrace();
                return null;
        }
    }
}
