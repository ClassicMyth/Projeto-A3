package com.mycompany.DAO;

import com.mycompany.classes.Usuario;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class DAO {
    public boolean existe (Usuario usuario) throws Exception{
        String sql = "SELECT * FROM tb_usuario WHERE nomeusu = ? AND senhausu = ?";
        
        ConnectionFactory cf = new ConnectionFactory();

        try (Connection conn = cf.obtemConexao();
            PreparedStatement ps = conn.prepareStatement(sql)){
            
            ps.setString(1, usuario.getUsuario());
            ps.setString(2, usuario.getSenha());

            try (ResultSet rs = ps.executeQuery()){
            return rs.next();
            }
        }
    }
}
