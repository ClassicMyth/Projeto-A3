package com.mycompany.classes;

import com.mycompany.DAO.ConnectionFactory;

public class TesteConexao {
    
    public static void main(String[] args) {
        System.out.println("<<OK>>");
        ConnectionFactory cf = new ConnectionFactory();
        cf.obtemConexao();
    }
    
}
