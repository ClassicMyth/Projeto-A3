/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.projetoa3.tchauplastico;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author Gabriel
 */
public class TchauPlastico {

    public static void main(String[] args) {
        connect();
    }

    // database paramethers
    private static String URL = "jdbc:mysql://127.0.0.1:3306/login?serverTimezone=America/Sao_Paulo";
    private static String USER = "root";
    private static String PASSWORD = "180504";

    public static Connection connect() {
        Connection connection = null;

        try {
            connection = DriverManager.getConnection(URL, USER, PASSWORD);
            System.out.println("Conectado ao banco de dados!");
        } catch (SQLException e) {
            System.out.println("Erro ao conectar");
            System.out.println(e.getMessage());
        }
        return connection;
    }
    
}
